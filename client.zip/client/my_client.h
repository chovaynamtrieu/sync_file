#ifndef MYCLIENT_H
#define MYCLIENT_H
#include <QObject>
#include <QTcpSocket>


class MyClient : public QObject
{
    Q_OBJECT

public:
    explicit MyClient(QObject *parent = nullptr);
    void sendMessage(const QString& message);
public slots:
    void connectToServer(const QString& host, quint16 port);
    void disconnectFromServer();
signals:
    void connected();
    void dataReceived(const QByteArray& data);
    void connectionError(const QString& error);
private slots:
    void onConnected();
    void onReadyRead();
    void onError(QAbstractSocket::SocketError socketError);

private:
    QTcpSocket *socket;
};

#endif // MYCLIENT_H
