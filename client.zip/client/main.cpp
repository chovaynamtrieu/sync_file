#include <QtNetwork/QTcpSocket>
#include <QtCore/QDebug>
#include <QCoreApplication>
#include <QtCore/QThread>

#include <iostream>
#include <fstream>
#include <QFile>
#include "my_client.h"

int main(int argc, char* argv[])
{
    QCoreApplication app(argc, argv);

    MyClient client;
    client.connectToServer("192.168.0.104", 1234);

    QObject::connect(&client, &MyClient::connected, []() {
        qDebug() << "Connected to server";
    });

    QObject::connect(&client, &MyClient::dataReceived, [](const QByteArray& data) {
        qDebug() << "Received response";
        QString fileName;
        QByteArray dataCopy = data;
        int separatorIndex = data.indexOf("\r\n");
        if (separatorIndex != -1) {
            fileName = QString::fromUtf8(data.left(separatorIndex));
            dataCopy.remove(0, separatorIndex + 2);
        }
        //QFile file("D:\\New_folder_(5)\\repository\\New_folder\\New_folder_(4)\\viettel-high-tech\\bai_tap\\client\\response.txt");
        QFile file(fileName);
        if (file.open(QIODevice::WriteOnly)) {
            file.write(dataCopy);
            qDebug() << "writed file!";
            file.close();
        }
    });

    QObject::connect(&client, &MyClient::connectionError, [](const QString& error) {
        qDebug() << "Connection error: " << error;
    });
    return app.exec();
}
