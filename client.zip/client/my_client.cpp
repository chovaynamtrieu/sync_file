#include "my_client.h"
#include <QObject>
#include <QTcpSocket>
#include <QAbstractSocket>

MyClient::MyClient(QObject *parent)
    : QObject(parent){
    socket = new QTcpSocket(this);
    connect(socket, &QTcpSocket::connected, this, &MyClient::onConnected);
    connect(socket, &QTcpSocket::readyRead, this, &MyClient::onReadyRead);
    connect(socket, SIGNAL(error(QAbstractSocket::SocketError)), this, SLOT(onError(QAbstractSocket::SocketError)));
}

void MyClient::sendMessage(const QString& message){
    QByteArray data = message.toUtf8();
    socket->write(data);
    socket->waitForBytesWritten();
}

void MyClient::connectToServer(const QString& host, quint16 port)
{
    socket->connectToHost(host, port);
    if (!socket->waitForConnected()) {
        emit connectionError(socket->errorString());
    }
}

void MyClient::disconnectFromServer()
{
    socket->disconnectFromHost();
}

void MyClient::onConnected()
{
    emit connected();
}

void MyClient::onReadyRead()
{
    QByteArray data = socket->readAll();
    emit dataReceived(data);
}

void MyClient::onError(QAbstractSocket::SocketError socketError)
{
    QString errorString = socket->errorString();
    emit connectionError(errorString);
}
